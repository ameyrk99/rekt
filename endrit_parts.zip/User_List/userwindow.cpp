#include "userwindow.h"
#include "ui_userwindow.h"

#include <QtCore>
#include <QStringList>
#include <QtGui>
#include <vector>
#include <iostream>
#include <string>

UserWindow::UserWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::UserWindow)
{
    ui->setupUi(this);

    model = new QStringListModel(this);
    QStringList list;

    Collection books;
    books.read_file();
    books_stored=books.get_list();
    std::vector<int> id_nums;
    id_nums.push_back(9);
    id_nums.push_back(99);
    id_nums.push_back(549);
    id_nums.push_back(109);
    id_nums.push_back(38);
    id_nums.push_back(8);
    id_nums.push_back(333);
    id_nums.push_back(51);
    id_nums.push_back(288);
    id_nums.push_back(400);
    id_nums.push_back(0);
    id_nums.push_back(199);
    id_nums.push_back(1);
    id_nums.push_back(478);
    id_nums.push_back(2);
    id_nums.push_back(280);
    id_nums.push_back(3);
    id_nums.push_back(12);
    id_nums.push_back(4);
    id_nums.push_back(376);
    id_nums.push_back(5);
    id_nums.push_back(79);
    id_nums.push_back(123);
    id_nums.push_back(499);
    id_nums.push_back(90);
    id_list=id_nums;
    QFont f("Avenir", 14, QFont::Cursive);

    QString book_chosen1;
    std::string book_chosen;

    for(int i = 0; i < id_list.size(); i++)
    {
        book_chosen = books_stored[id_list[i]].title + " by " + books_stored[id_list[i]].author+" ("+std::to_string(books_stored[id_list[i]].year)+ ")";
        book_chosen1=QString::fromStdString(book_chosen);
        list << book_chosen1;
        list.join("\n");
    }

    model->setStringList(list);
    ui->userlistView->setModel(model);
    ui->userlistView->setFont(f);
    ui->userlistcomboBox->setModel(model);

    ui->detailsButton->setFont(f);
    ui->deleteButton->setFont(f);
    ui->userlistcomboBox->setFont(f);

    ui->userlistView->setEditTriggers(QAbstractItemView::AnyKeyPressed | QAbstractItemView::DoubleClicked);
}

UserWindow::~UserWindow()
{
    delete ui;
}

void UserWindow::on_detailsButton_clicked()
{

}

void UserWindow::on_deleteButton_clicked()
{
    model->removeRows(ui->userlistView->currentIndex().row(), 1);
}
