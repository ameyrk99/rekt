/********************************************************************************
** Form generated from reading UI file 'bookwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BOOKWINDOW_H
#define UI_BOOKWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDial>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BookWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QLabel *label_genre;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *genre_crime;
    QCheckBox *genre_ficiton;
    QCheckBox *genre_non_fiction;
    QCheckBox *genre_mystery;
    QCheckBox *genre_classic;
    QCheckBox *genre_manga;
    QCheckBox *genre_sci_fi;
    QHBoxLayout *horizontalLayout;
    QCheckBox *genre_historical;
    QCheckBox *genre_horror;
    QCheckBox *genre_thriller;
    QCheckBox *genre_romance;
    QCheckBox *genre_cookbook;
    QCheckBox *genre_suspense;
    QCheckBox *genre_humor;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_year;
    QHBoxLayout *horizontalLayout_4;
    QSpinBox *spinBox_year;
    QSlider *slider_year;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_rating;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_stars;
    QSpinBox *spinBox_rating;
    QDial *dial_rating;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *BookWindow)
    {
        if (BookWindow->objectName().isEmpty())
            BookWindow->setObjectName(QStringLiteral("BookWindow"));
        BookWindow->resize(969, 378);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 217));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        QBrush brush1(QColor(0, 0, 0, 63));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        BookWindow->setPalette(palette);
        centralWidget = new QWidget(BookWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout_3 = new QVBoxLayout(centralWidget);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_genre = new QLabel(centralWidget);
        label_genre->setObjectName(QStringLiteral("label_genre"));
        label_genre->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_genre);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        genre_crime = new QCheckBox(centralWidget);
        genre_crime->setObjectName(QStringLiteral("genre_crime"));

        horizontalLayout_2->addWidget(genre_crime);

        genre_ficiton = new QCheckBox(centralWidget);
        genre_ficiton->setObjectName(QStringLiteral("genre_ficiton"));

        horizontalLayout_2->addWidget(genre_ficiton);

        genre_non_fiction = new QCheckBox(centralWidget);
        genre_non_fiction->setObjectName(QStringLiteral("genre_non_fiction"));

        horizontalLayout_2->addWidget(genre_non_fiction);

        genre_mystery = new QCheckBox(centralWidget);
        genre_mystery->setObjectName(QStringLiteral("genre_mystery"));

        horizontalLayout_2->addWidget(genre_mystery);

        genre_classic = new QCheckBox(centralWidget);
        genre_classic->setObjectName(QStringLiteral("genre_classic"));

        horizontalLayout_2->addWidget(genre_classic);

        genre_manga = new QCheckBox(centralWidget);
        genre_manga->setObjectName(QStringLiteral("genre_manga"));

        horizontalLayout_2->addWidget(genre_manga);

        genre_sci_fi = new QCheckBox(centralWidget);
        genre_sci_fi->setObjectName(QStringLiteral("genre_sci_fi"));

        horizontalLayout_2->addWidget(genre_sci_fi);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        genre_historical = new QCheckBox(centralWidget);
        genre_historical->setObjectName(QStringLiteral("genre_historical"));

        horizontalLayout->addWidget(genre_historical);

        genre_horror = new QCheckBox(centralWidget);
        genre_horror->setObjectName(QStringLiteral("genre_horror"));

        horizontalLayout->addWidget(genre_horror);

        genre_thriller = new QCheckBox(centralWidget);
        genre_thriller->setObjectName(QStringLiteral("genre_thriller"));

        horizontalLayout->addWidget(genre_thriller);

        genre_romance = new QCheckBox(centralWidget);
        genre_romance->setObjectName(QStringLiteral("genre_romance"));

        horizontalLayout->addWidget(genre_romance);

        genre_cookbook = new QCheckBox(centralWidget);
        genre_cookbook->setObjectName(QStringLiteral("genre_cookbook"));

        horizontalLayout->addWidget(genre_cookbook);

        genre_suspense = new QCheckBox(centralWidget);
        genre_suspense->setObjectName(QStringLiteral("genre_suspense"));

        horizontalLayout->addWidget(genre_suspense);

        genre_humor = new QCheckBox(centralWidget);
        genre_humor->setObjectName(QStringLiteral("genre_humor"));

        horizontalLayout->addWidget(genre_humor);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_3->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_year = new QLabel(centralWidget);
        label_year->setObjectName(QStringLiteral("label_year"));
        label_year->setMouseTracking(false);
        label_year->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_year);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        spinBox_year = new QSpinBox(centralWidget);
        spinBox_year->setObjectName(QStringLiteral("spinBox_year"));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        spinBox_year->setPalette(palette1);
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        font.setKerning(true);
        spinBox_year->setFont(font);
        spinBox_year->setAutoFillBackground(false);
        spinBox_year->setInputMethodHints(Qt::ImhNone);
        spinBox_year->setAlignment(Qt::AlignCenter);
        spinBox_year->setReadOnly(false);
        spinBox_year->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spinBox_year->setCorrectionMode(QAbstractSpinBox::CorrectToNearestValue);
        spinBox_year->setMinimum(-720);
        spinBox_year->setMaximum(2018);

        horizontalLayout_4->addWidget(spinBox_year);

        slider_year = new QSlider(centralWidget);
        slider_year->setObjectName(QStringLiteral("slider_year"));
        slider_year->setMinimumSize(QSize(0, 0));
        slider_year->setMaximumSize(QSize(1300, 1300));
        slider_year->setSizeIncrement(QSize(0, 0));
        slider_year->setMinimum(-720);
        slider_year->setMaximum(2018);
        slider_year->setSliderPosition(-720);
        slider_year->setOrientation(Qt::Horizontal);

        horizontalLayout_4->addWidget(slider_year);


        verticalLayout_2->addLayout(horizontalLayout_4);


        verticalLayout_3->addLayout(verticalLayout_2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_rating = new QLabel(centralWidget);
        label_rating->setObjectName(QStringLiteral("label_rating"));
        label_rating->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(label_rating);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_stars = new QLabel(centralWidget);
        label_stars->setObjectName(QStringLiteral("label_stars"));
        label_stars->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_5->addWidget(label_stars);

        spinBox_rating = new QSpinBox(centralWidget);
        spinBox_rating->setObjectName(QStringLiteral("spinBox_rating"));
        spinBox_rating->setMinimumSize(QSize(10, 0));
        spinBox_rating->setMaximumSize(QSize(50, 20));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Text, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        spinBox_rating->setPalette(palette2);
        spinBox_rating->setAutoFillBackground(false);
        spinBox_rating->setInputMethodHints(Qt::ImhNone);
        spinBox_rating->setAlignment(Qt::AlignCenter);
        spinBox_rating->setButtonSymbols(QAbstractSpinBox::PlusMinus);
        spinBox_rating->setMinimum(1);
        spinBox_rating->setMaximum(5);

        horizontalLayout_5->addWidget(spinBox_rating);

        dial_rating = new QDial(centralWidget);
        dial_rating->setObjectName(QStringLiteral("dial_rating"));
        dial_rating->setMinimum(1);
        dial_rating->setMaximum(5);
        dial_rating->setOrientation(Qt::Horizontal);

        horizontalLayout_5->addWidget(dial_rating);


        verticalLayout_4->addLayout(horizontalLayout_5);


        verticalLayout_3->addLayout(verticalLayout_4);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMaximumSize(QSize(150, 50));

        horizontalLayout_6->addWidget(pushButton);

        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMaximumSize(QSize(150, 50));

        horizontalLayout_6->addWidget(pushButton_2);


        verticalLayout_3->addLayout(horizontalLayout_6);

        BookWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(BookWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 969, 22));
        BookWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(BookWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        BookWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(BookWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        BookWindow->setStatusBar(statusBar);

        retranslateUi(BookWindow);

        QMetaObject::connectSlotsByName(BookWindow);
    } // setupUi

    void retranslateUi(QMainWindow *BookWindow)
    {
        BookWindow->setWindowTitle(QApplication::translate("BookWindow", "BookWindow", nullptr));
        label_genre->setText(QApplication::translate("BookWindow", "What genre are you interested in?", nullptr));
        genre_crime->setText(QApplication::translate("BookWindow", "Crime", nullptr));
        genre_ficiton->setText(QApplication::translate("BookWindow", "Fiction", nullptr));
        genre_non_fiction->setText(QApplication::translate("BookWindow", "Non-Fiction", nullptr));
        genre_mystery->setText(QApplication::translate("BookWindow", "Mystery", nullptr));
        genre_classic->setText(QApplication::translate("BookWindow", "Classic", nullptr));
        genre_manga->setText(QApplication::translate("BookWindow", "Manga", nullptr));
        genre_sci_fi->setText(QApplication::translate("BookWindow", "Sci-Fi", nullptr));
        genre_historical->setText(QApplication::translate("BookWindow", "Historical", nullptr));
        genre_horror->setText(QApplication::translate("BookWindow", "Horror", nullptr));
        genre_thriller->setText(QApplication::translate("BookWindow", "Thriller", nullptr));
        genre_romance->setText(QApplication::translate("BookWindow", "Romance", nullptr));
        genre_cookbook->setText(QApplication::translate("BookWindow", "Cookbook", nullptr));
        genre_suspense->setText(QApplication::translate("BookWindow", "Suspense", nullptr));
        genre_humor->setText(QApplication::translate("BookWindow", "Humor", nullptr));
        label_year->setText(QApplication::translate("BookWindow", "Year Released", nullptr));
        label_rating->setText(QApplication::translate("BookWindow", "Rating", nullptr));
        label_stars->setText(QApplication::translate("BookWindow", "Stars:", nullptr));
        pushButton->setText(QApplication::translate("BookWindow", "Find", nullptr));
        pushButton_2->setText(QApplication::translate("BookWindow", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BookWindow: public Ui_BookWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BOOKWINDOW_H
